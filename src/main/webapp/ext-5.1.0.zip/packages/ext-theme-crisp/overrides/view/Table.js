Ext.define('Ext.theme.crisp.view.Table', {
    override: 'Ext.view.Table',
    stripeRows: false
});